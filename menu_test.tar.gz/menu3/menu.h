/**************************************************************************************************/
/* Copyright (C) mc2lab.com, SSE@USTC, 2014-2015                                                  */
/*                                                                                                */
/*  FILE NAME             :  menu.h                                                               */
/*  PRINCIPAL AUTHOR      :  Wan Hui (Copy from Mengning's program)                                                            */
/*  SUBSYSTEM NAME        :  menu                                                                 */
/*  MODULE NAME           :  menu                                                                 */
/*  LANGUAGE              :  C                                                                    */
/*  TARGET ENVIRONMENT    :  ANY                                                                  */
/*  DATE OF FIRST RELEASE :  2014/09/21                                                           */
/*  DESCRIPTION           :  This is a menu program                                               */
/**************************************************************************************************/

/*
 * Revision log:
 *
 * Created by Wan Hui, 2014/09/21
 *
 */

#ifndef _MENU_H
#define _MENU_H

#include "linklist.h"

#define DESC_LEN	1024
#define CMD_NUM		10
#define CMD_MAX_LEN 128

int CreateMenu(tDataNode *head);
int AddMenu(tDataNode *head, char *cmd);
int Help(tDataNode *head);
int MenuStart(tDataNode *head);

/* Remove this head[], by using InitLinkList function */
/*
static tDataNode head[] = 
{
	{"help","This is help cmd!",Help,&head[1]},
	{"version","menu program v1.0",NULL,NULL}
};
*/


#endif
