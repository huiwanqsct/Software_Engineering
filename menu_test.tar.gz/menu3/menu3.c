/**************************************************************************************************/
/* Copyright (C) mc2lab.com, SSE@USTC, 2014-2015                                                  */
/*                                                                                                */
/*  FILE NAME             :  menu3.c                                                               */
/*  PRINCIPAL AUTHOR      :  Wan Hui (Copy from Mengning's program)                                                            */
/*  SUBSYSTEM NAME        :  menu                                                                 */
/*  MODULE NAME           :  menu                                                                 */
/*  LANGUAGE              :  C                                                                    */
/*  TARGET ENVIRONMENT    :  ANY                                                                  */
/*  DATE OF FIRST RELEASE :  2014/09/21                                                           */
/*  DESCRIPTION           :  This is a menu program                                               */
/**************************************************************************************************/

/*
 * Revision log:
 *
 * Created by Wan Hui, 2014/09/21
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include "linklist.h"
#include "menu.h"

tDataNode * head = NULL;

/* Init a cmd line by default, only have 2 cmds */
int CreateMenu(tDataNode *head)
{
	AddCmd(head,"Help");
	AddCmd(head,"Version");
	return 0;
}

int AddMenu(tDataNode *head, char *cmd)
{
	AddCmd(head, cmd);
	return 0;
}

int Help(tDataNode *head)
{
	ShowAllCmd(head);
	return 0;
}

int Quit(tDataNode *head)
{
	exit(0);
}

int MenuStart(tDataNode *head)
{	
	char cmd[CMD_MAX_LEN];
	printf("Input a cmd > ");
	scanf("%s",cmd);
	tDataNode *p = FindCmd(head, cmd);
	if (p == NULL)
	{
		printf("This is a wrong cmd!\n");
		return -1;
	}
	if (p->handler != NULL)
	{
		p->handler();
	}
	return 0;
}

/*
int main()
{
	while(1)
	{
		MenuStart(head);
	}
	return 0;
}
*/


