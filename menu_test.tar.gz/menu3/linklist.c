/**************************************************************************************************/
/* Copyright (C) mc2lab.com, SSE@USTC, 2014-2015                                                  */
/*                                                                                                */
/*  FILE NAME             :  linklist.c                                                               */
/*  PRINCIPAL AUTHOR      :  Wan Hui (Copy from Mengning's program)                                                            */
/*  SUBSYSTEM NAME        :  linklist                                                                 */
/*  MODULE NAME           :  linklist function                                                                 */
/*  LANGUAGE              :  C                                                                    */
/*  TARGET ENVIRONMENT    :  ANY                                                                  */
/*  DATE OF FIRST RELEASE :  2014/09/21                                                           */
/*  DESCRIPTION           :  This is a linklist program                                               */
/**************************************************************************************************/

/*
 * Revision log:
 *
 * Created by Wan Hui, 2014/09/21
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include "linklist.h"

/* test stub for AddCmd */
int AddCmd(tDataNode *head, char *cmd)
{
	return 0;
}

tDataNode* FindCmd(tDataNode * head, char * cmd)
{
	tDataNode *p = head;
	if (head == NULL || cmd == NULL)
	{
		return NULL;
	}
	while (p != NULL)
	{
		if (!strcmp(p->cmd, cmd))
		{
			return p;
		}
		p = p->next;
	}
	return NULL;
}

int ShowAllCmd(tDataNode * head)
{
	printf("Menu List:\n");
	tDataNode *p = head;
	while(p != NULL)
	{
		printf("%s - %s\n",p->cmd,p->desc);
		p = p->next;
	}	
	
	return 0;
}


