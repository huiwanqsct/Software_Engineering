/**************************************************************************************************/
/* Copyright (C) mc2lab.com, SSE@USTC, 2014-2015                                                  */
/*                                                                                                */
/*  FILE NAME             :  menu.h                                                               */
/*  PRINCIPAL AUTHOR      :  Wan Hui (Copy from Mengning's program)                                                            */
/*  SUBSYSTEM NAME        :  menu                                                                 */
/*  MODULE NAME           :  menu                                                                 */
/*  LANGUAGE              :  C                                                                    */
/*  TARGET ENVIRONMENT    :  ANY                                                                  */
/*  DATE OF FIRST RELEASE :  2014/09/21                                                           */
/*  DESCRIPTION           :  This is a menu program                                               */
/**************************************************************************************************/

/*
 * Revision log:
 *
 * Created by Wan Hui, 2014/09/21
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include "menu.h"
#include "linklist.h"

#define FAILURE -1
#define SUCCESS 0
#define debug

static tDataNode * head = NULL;
int result[4] = {1,1,1,1};
char * info[5] = 
{
	"Test report",
	"TC1 CreateMenu",
	"TC2 AddMenu",
	"TC3 Help",
	"TC4 MenuStart"
};

int main(void)
{
	int i;
	head = (tDataNode *)malloc(sizeof(tDataNode));
	char * cmd_try[4] = 
	{
		"Put",
		"Help",
		"Version",
		NULL
	};
	if (head == NULL)
	{
		printf("Malloc failed!\n");
		return -1;
	}
	if (FAILURE == CreateMenu(head))
	{
		debug("TC1 fail");
		result[1] = 0;
	}
	if (FAILURE == Help(head))
	{
		debug("TC3 fail");
		result[3] = 0;
	}
	for (i = 0; i < 4; i++)
	{
		if (FAILURE == AddMenu(head, cmd_try[i]))
		{
			debug("TC2 fail");
			result[2] = 0;
		}
		MenuStart(head);
	}

	/* test report */
	printf("test report\n");
	for (i = 1; i <= 4; i++)
	{
		if (1 == result[i])
		{
			printf("Testcase Number%d F - %s\n",i,info[i]);
		}
	}
	return 0;
}




