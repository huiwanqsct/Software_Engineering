/**************************************************************************************************/
/* Copyright (C) mc2lab.com, SSE@USTC, 2014-2015                                                  */
/*                                                                                                */
/*  FILE NAME             :  linklist.h                                                              */
/*  PRINCIPAL AUTHOR      :  Wan Hui (Copy from Mengning's program)                                                            */
/*  SUBSYSTEM NAME        :  linklist                                                                 */
/*  MODULE NAME           :  linklist function                                                                 */
/*  LANGUAGE              :  C                                                                    */
/*  TARGET ENVIRONMENT    :  ANY                                                                  */
/*  DATE OF FIRST RELEASE :  2014/09/21                                                           */
/*  DESCRIPTION           :  This is a linklist program                                               */
/**************************************************************************************************/

/*
 * Revision log:
 *
 * Created by Wan Hui, 2014/09/21
 *
 */

typedef struct DateNode
{
	char *cmd;
	char *desc;
	int  (*handler)();
	struct DateNode *next;
}tDataNode;

tDataNode* FindCmd(tDataNode * head, char * cmd);

int ShowAllCmd(tDataNode * head);

