/**************************************************************************************************/
/* Copyright (C) mc2lab.com, SSE@USTC, 2014-2015                                                  */
/*                                                                                                */
/*  FILE NAME             :  menu2.c                                                               */
/*  PRINCIPAL AUTHOR      :  Wan Hui (Copy from Mengning's program)                                                            */
/*  SUBSYSTEM NAME        :  menu                                                                 */
/*  MODULE NAME           :  menu                                                                 */
/*  LANGUAGE              :  C                                                                    */
/*  TARGET ENVIRONMENT    :  ANY                                                                  */
/*  DATE OF FIRST RELEASE :  2014/09/21                                                           */
/*  DESCRIPTION           :  This is a menu program                                               */
/**************************************************************************************************/

/*
 * Revision log:
 *
 * Created by Wan Hui, 2014/09/21
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include "linklist.h"
#include "menu.h"

int Help()
{
	ShowAllCmd(head);
	return 0;
}

int main()
{
	while(1)
	{
		char cmd[CMD_MAX_LEN];
		printf("Input a cmd > ");
		scanf("%s",cmd);
		tDataNode *p = FindCmd(head, cmd);
		if (p == NULL)
		{
			printf("This is a wrong cmd!\n");
			continue;
		}
		if (p->handler != NULL)
		{
			p->handler();
		}
	}
	return 0;
}


